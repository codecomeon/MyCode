module.exports = {
    'secret': 'haha,haha',
    'database': 'mongodb://127.0.0.1'
};