<?php
	$up = $_GET["up"];
	
	if( $up == "123456"){
		echo "y";
	}else{
		echo "n";
	}
?>