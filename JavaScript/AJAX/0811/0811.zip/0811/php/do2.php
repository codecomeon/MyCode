<?php
	echo "我是服务器我接收到了一个post请求参数是".$_POST["xingming"].$_POST["age"];
	
	
?>