<?php
	echo "我是服务器我接收到了一个get请求参数是".$_GET["wenben"];
?>