<?php
	$un = $_GET["un"];
	
	if( $un == "admin"){
		echo "y";
	}else{
		echo "n";
	}
?>