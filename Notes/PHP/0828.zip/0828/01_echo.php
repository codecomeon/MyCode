<!--<?php
	echo 1 + 2 * 3; //7
	echo "<br />";
	echo (1 + 2 * 3); //7
?>-->

<?php
	$a = 5;
	$b = "aaa";
	$c = true;
	
	echo $a."<br />";
	echo $b."<br />";
	echo $c."<br />";
?>